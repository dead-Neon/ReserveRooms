package ilyb;

@FunctionalInterface
public interface Scoreable {
   int getScore();
}

